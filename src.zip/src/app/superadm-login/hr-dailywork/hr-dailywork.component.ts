import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-dailywork',
  templateUrl: './hr-dailywork.component.html',
  styleUrls: ['./hr-dailywork.component.css']
})
export class HrDailyworkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
