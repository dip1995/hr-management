import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-leave-application',
  templateUrl: './hr-leave-application.component.html',
  styleUrls: ['./hr-leave-application.component.css']
})
export class HrLeaveApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
